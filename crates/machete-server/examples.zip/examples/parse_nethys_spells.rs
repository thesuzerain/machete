use std::{collections::HashMap, fs::read_to_string};

use lazy_static::lazy_static;
use machete::models::library::{spell::LibrarySpell, GameSystem, Rarity};
use serde::{Deserialize, Serialize};

lazy_static! {
    /// Regex for extracting digits from a string
    static ref DIGIT_PARSER: regex::Regex = regex::Regex::new(r"\d+").unwrap();
}

/// A spell as stored in the Archives of Nethys table export
#[derive(Deserialize, Serialize, Debug)]
pub struct NethysSpell {
    /// Name of the spell
    name: String,
    /// Spell type
    spell_type: String,
    /// Rank
    rank: String,
    /// Heighten
    heighten: String,
    /// Tradition
    tradition: String,
    /// School
    school: String,
    /// Traits assigned to the object, comma separated
    r#trait: String,
    /// Actions
    actions: String,
    /// Component
    component: String,
    /// Trigger
    trigger: String,
    /// Range
    range: String,
    /// Area
    area: String,
    /// Duration
    duration: String,
    /// Defense
    defense: String,
    /// Rarity of the spell
    rarity: Rarity,
    /// Mystery
    mystery: String,
    /// Lesson
    lesson: String,
    /// Patron Theme
    patron_theme: String,
    /// Summary
    summary: String,
    /// URL
    url: String,

    /// Missed fields
    /// TODO: remove
    #[serde(flatten)]
    missed_fields: HashMap<String, serde_json::Value>,
}

/// cargo run --example parse_nethys_spell
/// This example parses a table from the Archives of Nethys website and converts to Machete-friendly format
// TODO: Shouldn't be in examples, make a parser crate (with stuff like NLP or semantic similarity, etc.)
// Instructions:
// 1. Download the JSON file from the Archives of Nethys website. Use the 'table' setting under 'Result display', and add every column.
// - Not all are needed. The ones used are:
//  - The "Spell" group
//  (and then, in addition)
//  - Summary
//  - Mystery
//  - Lesson
//  - Url
//  - Lesson
//  - Patron Theme
// https://2e.aonprd.com/Spells.aspx?sort=spell_type-asc+rank-asc+name-asc&display=table&columns=spell_type+rank+heighten+tradition+school+trait+actions+component+trigger+target+range+area+duration+defense+rarity+pfs+mystery+lesson+patron_theme+summary+url
// 2. Save as a JSON file in the fixtures directory, and point the `filepath` variable to it.
// 3. Run the example with `cargo run --example parse_nethys_spell`
// 4. The output will be saved to the `fixtures` directory. It can be loaded into the demo_library fixture.
// TODO: Adjust these instructions when we have a database and a dedicated parser crate.
#[tokio::main(flavor = "current_thread")]
async fn main() {
    let filepath = "fixtures/nethys-spells.json";
    let output_filepath = "fixtures/machete-spells.json";

    // Load the JSON file
    let text = read_to_string(filepath).unwrap();

    // Parse the JSON file
    let spells: Vec<NethysSpell> = serde_json::from_str(&text).unwrap();
    let num_spells = spells.len();

    // Convert to Vec<LibrarySpell>
    let spells: Vec<LibrarySpell> = spells
        .into_iter()
        .filter_map(|spell| {
            println!("Parsing spell: {:?}", spell);
            Some(LibrarySpell {
                name: spell.name,
                game_system: GameSystem::PF2E,
                rarity: spell.rarity,
                rank: parse_rank(&spell.rank).unwrap(),
                tags: parse_tags(vec![spell.r#trait, spell.spell_type]),
            })
        })
        .collect();

    // Print the number of spells parsed
    println!("Successfully parsed {}/{} spells", spells.len(), num_spells);

    // Write to output file
    let output = serde_json::to_string_pretty(&spells).unwrap();
    std::fs::write(output_filepath, output).unwrap();

    // POST to the server
    reqwest::Client::new()
        .post("http://localhost:8000/library/spells")
        .json(&spells)
        .send()
        .await
        .unwrap()
        .error_for_status()
        .unwrap();
}

lazy_static::lazy_static! {
    static ref GOLD_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?gp").unwrap();
    static ref SILVER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?sp").unwrap();
    static ref COPPER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?cp").unwrap();
}

fn parse_rank(rank: &str) -> Option<u8> {
    DIGIT_PARSER.find(rank)?.as_str().parse().ok()
}

fn parse_tags(potential_taggables: Vec<String>) -> Vec<String> {
    let mut tags = vec![];
    for taggable in potential_taggables {
        tags.extend(taggable.split(',').map(|tag| tag.trim().to_string()));
    }
    tags
}
