use std::fs::read_to_string;

use machete::models::library::{
    item::{Currency, LibraryItem},
    GameSystem, Rarity,
};
use serde::{Deserialize, Serialize};

/// An item as stored in the Archives of Nethys table export
#[derive(Deserialize, Serialize, Debug)]
pub struct NethysItem {
    /// Name of the item
    name: String,
    /// Item category
    item_category: String,
    /// Item subcategory
    item_subcategory: String,
    /// Item level
    level: String,
    /// Item price
    price: String,
    /// Item bulk
    bulk: String,
    /// Traits assigned to the object, comma separated
    r#trait: String,
    /// Rarity of the item
    rarity: Rarity,
    /// PFS
    pfs: String,
    /// Summary
    summary: String,
    /// Base item
    base_item: String,
    /// URL
    url: String,
    /// Image
    image: String,
    /// Actions
    actions: String,
    /// Damage
    damage: String,
    /// Hands
    hands: String,
    /// Hardness
    hardness: String,
    /// HP
    hp: String,
    /// HP scale
    hp_scale: String,
    /// Onset
    onset: String,
    /// Range
    range: String,
    /// Size
    size: String,
    /// Stage
    stage: String,
    /// Trigger
    trigger: String,
    /// Item usage (ie: "held in 2 hands")
    usage: String,
}

/// cargo run --example parse_nethys_item
/// This example parses a table from the Archives of Nethys website and converts to Machete-friendly format
// TODO: Shouldn't be in examples, make a parser crate (with stuff like NLP or semantic similarity, etc.)
// Instructions:
// TODO: Do we need all of these?
// 1. Download the JSON file from the Archives of Nethys website. Use the 'table' setting under 'Result display', and add every column.
// - Not all are needed. The ones used are:
//  - The "Items" group
//  (and then, in addition)
//  - Summary
//  - Base Item
//  - Url
//  - Image
//  - Actions
//  - Damage
//  - Hands
//  - Hardness
//  - HP
//  - Hp scale
//  - Onset
//  - Range
//  - Size
//  - Stage
//  - Trigger
//  - Usage
// https://2e.aonprd.com/Equipment.aspx?sort=level-asc+price-asc+name-asc&display=table&columns=item_category+item_subcategory+level+price+bulk+trait+rarity+pfs+summary+base_item+url+image+actions+damage+hands+hardness+hp+hp_scale+onset+range+size+stage+trigger+usage
// 2. Save as a JSON file in the fixtures directory, and point the `filepath` variable to it.
// 3. Run the example with `cargo run --example parse_nethys_item`
// 4. The output will be saved to the `fixtures` directory. It can be loaded into the demo_library fixture.
// TODO: Adjust these instructions when we have a database and a dedicated parser crate.
#[tokio::main(flavor = "current_thread")]
async fn main() {
    let filepath = "fixtures/nethys-items.json";
    let output_filepath = "fixtures/machete-items.json";

    // Load the JSON file
    let text = read_to_string(filepath).unwrap();

    // Parse the JSON file
    let items: Vec<NethysItem> = serde_json::from_str(&text).unwrap();
    let num_items = items.len();

    // Convert to Vec<LibraryItem>
    let items: Vec<LibraryItem> = items
        .into_iter()
        .filter_map(|item| {
            println!("Parsing item: {:?}", item);
            Some(LibraryItem {
                name: item.name,
                price: parse_currency(&item.price).unwrap_or_default(),
                game_system: GameSystem::PF2E,
                rarity: item.rarity,
                level: item.level.parse().unwrap(),
                tags: parse_tags(vec![
                    item.r#trait,
                    item.item_category,
                    item.item_subcategory,
                    item.usage,
                    item.bulk,
                ]),
            })
        })
        .collect();

    // Print the number of items
    println!("Successfully parsed {}/{} items", items.len(), num_items);

    // Write to output file
    let output = serde_json::to_string_pretty(&items).unwrap();
    std::fs::write(output_filepath, output).unwrap();

    // POST to the server
    reqwest::Client::new()
        .post("http://localhost:8000/library/items")
        .json(&items)
        .send()
        .await
        .unwrap()
        .error_for_status()
        .unwrap();
}

lazy_static::lazy_static! {
    static ref GOLD_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?gp").unwrap();
    static ref SILVER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?sp").unwrap();
    static ref COPPER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?cp").unwrap();
}

fn parse_currency(currency: &str) -> Option<Currency> {
    let get_first_capture = |parser: &regex::Regex, currency: &str| {
        parser.captures(currency)?.get(1)?.as_str().parse().ok()
    };

    let gold = get_first_capture(&GOLD_PARSER, currency);
    let silver = get_first_capture(&SILVER_PARSER, currency);
    let copper = get_first_capture(&COPPER_PARSER, currency);

    if gold.is_none() && silver.is_none() && copper.is_none() {
        return None;
    }

    Some(Currency {
        gold: gold.unwrap_or(0),
        silver: silver.unwrap_or(0),
        copper: copper.unwrap_or(0),
    })
}

fn parse_tags(potential_taggables: Vec<String>) -> Vec<String> {
    let mut tags = vec![];
    for taggable in potential_taggables {
        tags.extend(taggable.split(',').map(|tag| tag.trim().to_string()));
    }
    tags
}

#[test]
fn test_currency_parse() {
    let currency = " ";
    let parsed = parse_currency(currency);
    assert_eq!(parsed, None);

    let currency = "1 gp";
    let parsed = parse_currency(currency);
    assert_eq!(
        parsed.unwrap(),
        Currency {
            gold: 1,
            silver: 0,
            copper: 0
        }
    );

    let currency = "1 sp";
    let parsed = parse_currency(currency);
    assert_eq!(
        parsed.unwrap(),
        Currency {
            gold: 0,
            silver: 1,
            copper: 0
        }
    );

    let currency = "1 gp 1 sp 1 cp";
    let parsed = parse_currency(currency);
    assert_eq!(
        parsed.unwrap(),
        Currency {
            gold: 1,
            silver: 1,
            copper: 1
        }
    );

    let currency = "1 gp 5sp 3cp";
    let parsed = parse_currency(currency);
    assert_eq!(
        parsed.unwrap(),
        Currency {
            gold: 1,
            silver: 5,
            copper: 3
        }
    );
}
