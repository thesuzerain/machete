use std::fs::read_to_string;

use machete::models::library::{
    creature::{Alignment, LibraryCreature, Size},
    GameSystem, Rarity,
};
use serde::{Deserialize, Serialize};

/// A creature as stored in the Archives of Nethys table export
#[derive(Deserialize, Serialize, Debug)]
pub struct NethysCreature {
    /// Name of the creature
    name: String,
    /// Creature level
    level: String,
    /// Creature family
    creature_family: String,
    /// Rarity of the creature
    rarity: Rarity,
    /// Size of the creature
    size: Size,
    /// Traits assigned to the object, comma separated
    r#trait: String,

    /// HP
    hp: String,
    /// HP scale
    hp_scale: String,
    /// AC
    ac: String,
    /// AC scale
    ac_scale: String,
    /// Fortitude
    fortitude: String,
    /// Fortitude scale
    fortitude_scale: String,
    /// Reflex
    reflex: String,
    /// Reflex scale
    reflex_scale: String,
    /// Will
    will: String,
    /// Will scale
    will_scale: String,
    /// Immunity
    immunity: String,
    /// Resistance
    resistance: String,
    /// Weakness
    weakness: String,
    /// Creature ability
    creature_ability: String,
    /// Perception
    perception: String,
    /// Perception scale
    perception_scale: String,
    /// Sense
    sense: String,
    /// Speed
    speed: String,
    /// Attack bonus
    attack_bonus: String,
    /// Attack bonus scale
    attack_bonus_scale: String,
    /// Strike damage average
    strike_damage_average: String,
    /// Strike damage scale
    strike_damage_scale: String,
    /// Spell attack
    spell_attack: String,
    /// Spell attack scale
    spell_attack_scale: String,
    /// Spell DC
    spell_dc: String,
    /// Spell DC scale
    spell_dc_scale: String,
    /// Spell
    spell: String,
    /// Language
    language: String,
    /// Strength
    strength: String,
    /// Strength scale
    strength_scale: String,
    /// Dexterity
    dexterity: String,
    /// Dexterity scale
    dexterity_scale: String,
    /// Constitution
    constitution: String,
    /// Constitution scale
    constitution_scale: String,
    /// Intelligence
    intelligence: String,
    /// Intelligence scale
    intelligence_scale: String,
    /// Wisdom
    wisdom: String,
    /// Wisdom scale
    wisdom_scale: String,
    /// Charisma
    charisma: String,
    /// Charisma scale
    charisma_scale: String,
    /// Skill
    skill: String,
    /// Summary
    summary: String,
    /// Alignment
    alignment: String,
    /// URL
    url: String,
    /// Vision
    vision: String,
}

/// cargo run --example parse_nethys_creature
/// This example parses a table from the Archives of Nethys website and converts to Machete-friendly format
// TODO: Shouldn't be in examples, make a parser crate (with stuff like NLP or semantic similarity, etc.)
// Instructions:
// 1. Download the JSON file from the Archives of Nethys website. Use the 'table' setting under 'Result display', and add every column.
// - Not all are needed. The ones used are:
//  - The "Creature (Extended)" group
//  (and then, in addition)
//  - Summary
//  - Alignment
//  - Url
//  - Vision
//  - Image
// https://2e.aonprd.com/Creatures.aspx?sort=name-asc&display=table&columns=level+creature_family+source+rarity+size+trait+hp+hp_scale+ac+ac_scale+fortitude+fortitude_scale+reflex+reflex_scale+will+will_scale+immunity+resistance+weakness+creature_ability+perception+perception_scale+sense+speed+attack_bonus+attack_bonus_scale+strike_damage_average+strike_damage_scale+spell_attack+spell_attack_scale+spell_dc+spell_dc_scale+spell+language+strength+strength_scale+dexterity+dexterity_scale+constitution+constitution_scale+intelligence+intelligence_scale+wisdom+wisdom_scale+charisma+charisma_scale+skill+summary+alignment+url+vision
// 2. Save as a JSON file in the fixtures directory, and point the `filepath` variable to it.
// 3. Run the example with `cargo run --example parse_nethys_creature`
// 4. The output will be saved to the `fixtures` directory. It can be loaded into the demo_library fixture.
// TODO: Adjust these instructions when we have a database and a dedicated parser crate.
#[tokio::main(flavor = "current_thread")]
async fn main() {
    let filepath = "fixtures/nethys-creatures.json";
    let output_filepath = "fixtures/machete-creatures.json";

    // prin teverything in "fixtures" folder
    let paths = std::fs::read_dir("fixtures").unwrap();
    for path in paths {
        println!("Name: {}", path.unwrap().path().display());
    }

    // Load the JSON file
    let text = read_to_string(filepath).unwrap();

    // Parse the JSON file
    let creatures: Vec<NethysCreature> = serde_json::from_str(&text).unwrap();
    let num_creatures = creatures.len();

    // Convert to Vec<LibraryCreature>
    let creatures: Vec<LibraryCreature> = creatures
        .into_iter()
        .filter_map(|creature| {
            println!("Parsing creature: {:?}", creature);
            Some(LibraryCreature {
                name: creature.name,
                game_system: GameSystem::PF2E,
                rarity: creature.rarity,
                size: creature.size,
                alignment: Alignment::None, // TODO
                level: creature.level.parse().unwrap(),
                tags: parse_tags(vec![creature.r#trait, creature.creature_family]),
            })
        })
        .collect();

    // Print the number of creatures parsed
    println!(
        "Successfully parsed {}/{} creatures",
        creatures.len(),
        num_creatures
    );

    // Write to output file
    let output = serde_json::to_string_pretty(&creatures).unwrap();
    std::fs::write(output_filepath, output).unwrap();

    // POST to the server
    reqwest::Client::new()
        .post("http://localhost:8000/library/creatures")
        .json(&creatures)
        .send()
        .await
        .unwrap()
        .error_for_status()
        .unwrap();
}

lazy_static::lazy_static! {
    static ref GOLD_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?gp").unwrap();
    static ref SILVER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?sp").unwrap();
    static ref COPPER_PARSER: regex::Regex = regex::Regex::new(r"(\d+) ?cp").unwrap();
}

fn parse_tags(potential_taggables: Vec<String>) -> Vec<String> {
    let mut tags = vec![];
    for taggable in potential_taggables {
        tags.extend(taggable.split(',').map(|tag| tag.trim().to_string()));
    }
    tags
}
